clearvars; close all;
subs = 1:19;

expChoiceData = zeros(6,4,7,length(subs)); % 6 icon probs, 4 pie types, 7 pie prob, pp
subnum = 1;
for currsub = subs
    filename = dir(['participant',num2str(currsub),'_dataExp2*.mat']);
    load (filename.name);

    datatab = table(trialIconsEXP2,cell2mat(trialPiechartTypesEXP2),cell2mat(trialPiechartProbsEXP2),selected_imageEXP2,cell2mat(selected_probabilityEXP2));
    datatab.Properties.VariableNames([2, 3, 5]) = {'PieTypes','PieProb','ChosenProb'};
    piechoice = arrayfun(@(x) strfind(x, 'Pie'), datatab.selected_imageEXP2);
    piechoiceidx = arrayfun(@(x) isempty(cell2mat(x)), piechoice);
    datatab.piechoice = ~piechoiceidx;
    pivtab = pivot_table(datatab,{'trialIconsEXP2', 'PieTypes','PieProb'},'piechoice',@sum);
    pietypes = unique(pivtab.PieTypes);
    pieprobs = unique(pivtab.PieProb);

    datatab2 = table(left_imagesEXP2,cell2mat(left_probabilityEXP2));
    datatab2.Properties.VariableNames(2) = {'IconProb'};
    icontab = pivot_table(datatab2,'left_imagesEXP2','IconProb',@mean);
    icontab = icontab(1:6,:);
    iconNames = icontab.left_imagesEXP2;
    iconProbSet = sort(icontab.mean_of_IconProb);
    
    for curricon = 1:length(iconNames)
        curriconProb = icontab.mean_of_IconProb(curricon);
        curriconProbidx = find(curriconProb==iconProbSet);
%         figure;hold on; aa = 1;
        for currpie = 1:length(pietypes)
            ydata = pivtab.sum_of_piechoice(strcmp(pivtab.trialIconsEXP2,iconNames{curricon})& pivtab.PieTypes==currpie);
            expChoiceData(curriconProbidx,currpie,:,subnum)=ydata;
%             plot(pieprobs,ydata);
%             aa = aa+1;
        end
%         axis([0 1 0 6]); title(['Icon Prob ', num2str(curriconProb)]); hold off;
    end
subnum = subnum+1;
end

avgdata = mean(expChoiceData,4)/5;
figure; aa = 1;
for pietype = 1:4
    choicedata = squeeze(avgdata(:,pietype,:));
    subplot(2,2,aa); plot(pieprobs,choicedata', 'LineWidth',2);
    axis([0 1 0 1]); title (['Pie type ', num2str(pietype)]); xlabel('Prob of winning (Piechart)'); ylabel('Prob of choosing Piechart');
    legend({'1/8','2/8','3/8','5/8','6/8','7/8'}, 'Location','northwest');
    aa = aa+1;
end

% datatab = table(trialIconsEXP2,left_probabilityEXP2,right_probabilityEXP2, selected_probabilityEXP2,selected_sideEXP2, trialPiechartTypesEXP2, trialPiechartProbsEXP2);
% isleftpie = arrayfun(@(x) strfind(x, 'Pie'), datatab.left_imagesEXP2);
% isleftpieidx = arrayfun(@(x) isempty(cell2mat(x)), isleftpie);
% datatab.isLeftItemAnIcon = isleftpieidx;
% 
% ag = cell(height(datatab),1);
% ag(isleftpieidx)=datatab.left_imagesEXP2(isleftpieidx);
% ag(~isleftpieidx)=datatab.right_imagesEXP2(~isleftpieidx);
% datatab.icons = ag;